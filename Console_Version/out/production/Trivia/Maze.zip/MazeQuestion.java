public class MazeQuestion {

}
